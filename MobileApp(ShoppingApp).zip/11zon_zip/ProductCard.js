// ProductCard.js
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image
} from 'react-native';

const ProductCard = ({ product, onPress, onAddToCart }) => {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={product.image} style={styles.image} />
      <View style={styles.details}>
        <Text style={styles.name}>{product.name}</Text>
        <Text style={styles.price}>Rs. {product.price}</Text>
        <Text style={styles.description} numberOfLines={2}>
          {product.description}
        </Text>
        
        {/* Add to Cart Button */}
        <TouchableOpacity 
          style={styles.addToCartButton}
          onPress={(e) => {
            e.stopPropagation(); // Prevent triggering the card's onPress
            onAddToCart();
          }}
        >
          <Text style={styles.addToCartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    margin: 8,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    overflow: 'hidden'
  },
  image: {
    width: '100%',
    height: 150,
    resizeMode: 'cover'
  },
  details: {
    padding: 12
  },
  name: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2F4F4F',
    marginBottom: 4
  },
  price: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000',
    marginBottom: 4
  },
  description: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8
  },
  addToCartButton: {
    backgroundColor: '#000000',
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: 5
  },
  addToCartText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold'
  }
});

export default ProductCard;