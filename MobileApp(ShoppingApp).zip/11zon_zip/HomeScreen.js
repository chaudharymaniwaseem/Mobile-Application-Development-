import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
  Modal,
  Animated
} from 'react-native';

const { width, height } = Dimensions.get('window');
const isMobile = width < 768;

const HomeScreen = ({ navigation }) => {
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const [slideAnim] = useState(new Animated.Value(-300));
  const [imageLoading, setImageLoading] = useState({});

  const categories = [
    {
      id: 1,
      name: 'Winter Collection',
      image: require('../assets/images/featured-1.jpg'),
      screen: 'Winter',
      color: '#000000'
    },
    {
      id: 2,
      name: 'Summer Collection',
      image: require('../assets/images/featured-2.jpg'),
      screen: 'Summer',
      color: '#000000'
    },
    {
      id: 3,
      name: 'Traditional Perfumes',
      image: require('../assets/images/perfumes-banner.jpg'),
      screen: 'Perfumes',
      color: '#000000'
    },
    {
      id: 4,
      name: 'Sale',
      image: require('../assets/images/featured-3.jpg'),
      screen: 'Sale',
      color: '#000000'
    }
  ];

  const recommendations = [
    {
      id: 1,
      name: '3 Piece Printed Suit',
      price: 4790,
      originalPrice: 5990,
      image: require('../assets/images/printed-fabric.jpg'),
      category: 'Summer',
      rating: 4.5,
      reviews: 128,
      description: 'UNSTITCHED • NEW IN'
    },
    {
      id: 2,
      name: 'Embroidered Lawn Suit',
      price: 3200,
      originalPrice: 4000,
      image: require('../assets/images/lawn-fabric.jpg'),
      category: 'Summer',
      rating: 4.2,
      reviews: 89,
      description: 'READY TO WEAR'
    },
    {
      id: 3,
      name: 'Velvet Winter Suit',
      price: 6500,
      originalPrice: 8200,
      image: require('../assets/images/embroidered-fabric.jpg'),
      category: 'Winter',
      rating: 4.8,
      reviews: 156,
      description: 'HEAVY EMBROIDERED'
    },
    {
      id: 4,
      name: 'Chiffon Party Dress',
      price: 5500,
      originalPrice: 6900,
      image: require('../assets/images/chiffon-dress.jpg'),
      category: 'Winter',
      rating: 4.3,
      reviews: 67,
      description: 'STITCHED • NEW ARRIVAL'
    }
  ];

  const handleImageLoad = (imageId) => {
    setImageLoading(prev => ({ ...prev, [imageId]: true }));
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Text key={i} style={styles.star}>⭐</Text>);
    }
    
    if (hasHalfStar) {
      stars.push(<Text key="half" style={styles.star}>⭐</Text>);
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Text key={`empty-${i}`} style={styles.star}>☆</Text>);
    }
    
    return stars;
  };

  const openSidebar = () => {
    setSidebarVisible(true);
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true
    }).start();
  };

  const closeSidebar = () => {
    Animated.timing(slideAnim, {
      toValue: -300,
      duration: 300,
      useNativeDriver: true
    }).start(() => {
      setSidebarVisible(false);
    });
  };

  const handleMenuClick = (item) => {
    closeSidebar();
    if (item === 'Home') {
      // Already on home, do nothing
    } else if (item === 'Cart') {
      navigation.navigate('Cart');
    }
  };

  const menuItems = ['Home', 'Cart', 'Contact Us', 'About'];

  return (
    <View style={styles.container}>
      <View style={styles.customHeader}>
        <TouchableOpacity onPress={openSidebar} style={styles.menuButton}>
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>
        
        <Text style={styles.headerTitle}>Riwaayat</Text>
        <TouchableOpacity style={styles.cartButton}
          onPress={() => navigation.navigate('Cart')}
        >
          <Text style={styles.cartIcon}>🛒</Text>
        </TouchableOpacity>
      </View>

      {/* Sidebar Menu */}
      <Modal
        visible={sidebarVisible}
        transparent={true}
        animationType="none"
        onRequestClose={closeSidebar}
      >
        <TouchableOpacity 
          style={styles.sidebarOverlay}
          activeOpacity={1}
          onPress={closeSidebar}
        >
          <Animated.View 
            style={[
              styles.sidebar,
              { transform: [{ translateX: slideAnim }] }
            ]}
          >
            <View style={styles.sidebarHeader}>
              <Text style={styles.sidebarTitle}>Riwaayat</Text>
              <TouchableOpacity onPress={closeSidebar} style={styles.closeButton}>
                <Text style={styles.closeIcon}>×</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.menuItems}>
              {menuItems.map((item, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.menuItem}
                  onPress={() => handleMenuClick(item)}
                >
                  <Text style={styles.menuItemText}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>
        </TouchableOpacity>
      </Modal>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Main Banner */}
        <View style={styles.bannerContainer}>
          <Image
            source={require('../assets/images/main-banner.jpg')}
            style={styles.bannerImage}
            resizeMode="cover"
            onLoad={() => handleImageLoad('main-banner')}
          />
        </View>

        {/* Quality Assurance Banner */}
        <View style={styles.qualityBanner}>
          <Text style={styles.qualityText}>
            ✅ Check Your Parcel Before Payment For Quality Assurance
          </Text>
          <TouchableOpacity style={styles.dismissButton}>
            <Text style={styles.dismissText}>Dismiss</Text>
          </TouchableOpacity>
        </View>

        {/* Categories Grid */}
        <View style={styles.categoriesContainer}>
          <Text style={styles.sectionTitle}>Shop Categories</Text>
          <View style={styles.categoriesGrid}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[styles.categoryCard, { borderLeftColor: category.color }]}
                onPress={() => navigation.navigate(category.screen)}
              >
                <Image
                  source={category.image}
                  style={styles.categoryImage}
                  resizeMode="cover"
                  onLoad={() => handleImageLoad(`category-${category.id}`)}
                />
                <View style={styles.categoryOverlay}>
                  <Text style={styles.categoryName}>{category.name}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recommendations Section */}
        <View style={styles.recommendationsContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.recommendationTitle}>Recommended for you</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Sale')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.recommendationsScroll}
          >
            {recommendations.map((item) => (
              <TouchableOpacity 
                key={item.id}
                style={styles.recommendationCard}
                onPress={() => navigation.navigate('ProductDetail', { product: item })}
              >
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>NEW</Text>
                </View>
                <Image
                  source={item.image}
                  style={styles.recommendationImage}
                  resizeMode="cover"
                  onLoad={() => handleImageLoad(`recommendation-${item.id}`)}
                />
                <View style={styles.recommendationInfo}>
                  <Text style={styles.recommendationName}>{item.name}</Text>
                  <Text style={styles.recommendationDescription}>{item.description}</Text>
                  
                  <View style={styles.ratingContainer}>
                    <View style={styles.starsContainer}>
                      {renderStars(item.rating)}
                    </View>
                    <Text style={styles.ratingText}>({item.reviews})</Text>
                  </View>
                  
                  <View style={styles.priceContainer}>
                    <Text style={styles.currentPrice}>Rs. {item.price}</Text>
                    <Text style={styles.originalPrice}>Rs. {item.originalPrice}</Text>
                    <Text style={styles.discount}>
                      {Math.round((1 - item.price/item.originalPrice) * 100)}% OFF
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Additional Banner */}
        <View style={styles.secondBannerContainer}>
          <Image
            source={require('../assets/images/perfumes-banner.jpg')}
            style={styles.secondBannerImage}
            resizeMode="cover"
            onLoad={() => handleImageLoad('perfumes-banner')}
          />
          <View style={styles.secondBannerOverlay}>
            <Text style={styles.secondBannerTitle}>Premium Attar Collection</Text>
            <Text style={styles.secondBannerSubtitle}>Traditional Scents & Perfumes</Text>
            <TouchableOpacity 
              style={styles.secondBannerButton}
              onPress={() => navigation.navigate('Perfumes')}
            >
              <Text style={styles.secondBannerButtonText}>Explore Scents</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF'
  },
  customHeader: {
    backgroundColor: '#000000',
    paddingHorizontal: isMobile ? 15 : 30,
    paddingVertical: isMobile ? 15 : 20,
    paddingTop: isMobile ? 35 : 25,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#333'
  },
  menuButton: {
    padding: 5
  },
  menuIcon: {
    fontSize: isMobile ? 20 : 24,
    color: '#FFFFFF',
    fontWeight: 'bold'
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: isMobile ? 20 : 28,
    fontWeight: 'bold'
  },
  cartButton: {
    padding: 5
  },
  cartIcon: {
    fontSize: isMobile ? 20 : 24,
    color: '#FFFFFF'
  },
  sidebarOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)'
  },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: isMobile ? 280 : 350,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 10
  },
  sidebarHeader: {
    backgroundColor: '#000000',
    padding: isMobile ? 20 : 30,
    paddingTop: isMobile ? 50 : 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  sidebarTitle: {
    color: '#FFFFFF',
    fontSize: isMobile ? 20 : 24,
    fontWeight: 'bold'
  },
  closeButton: {
    padding: 5
  },
  closeIcon: {
    color: '#FFFFFF',
    fontSize: isMobile ? 24 : 28,
    fontWeight: 'bold'
  },
  menuItems: {
    paddingVertical: 10
  },
  menuItem: {
    paddingVertical: isMobile ? 15 : 20,
    paddingHorizontal: isMobile ? 20 : 30,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0'
  },
  menuItemText: {
    fontSize: isMobile ? 16 : 18,
    color: '#000000',
    fontWeight: '500'
  },
  scrollView: {
    flex: 1
  },
  bannerContainer: {
    height: isMobile ? 300 : 500, // Increased height for better quality
    position: 'relative',
    marginBottom: 10
  },
  bannerImage: {
    width: '100%',
    height: '100%',
    backgroundColor: '#f8f5f0' // Fallback color while loading
  },
  qualityBanner: {
    backgroundColor: '#FFFBEB',
    padding: isMobile ? 12 : 16,
    marginHorizontal: isMobile ? 15 : 30,
    marginBottom: 20,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#10B981',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  qualityText: {
    color: '#065F46',
    fontSize: isMobile ? 14 : 16,
    fontWeight: '500',
    flex: 1
  },
  dismissButton: {
    marginLeft: 10
  },
  dismissText: {
    color: '#8B4513',
    fontSize: isMobile ? 12 : 14,
    fontWeight: '600'
  },
  categoriesContainer: {
    padding: isMobile ? 20 : 30,
    backgroundColor: '#FFFFFF'
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15
  },
  sectionTitle: {
    fontSize: isMobile ? 20 : 28,
    fontWeight: 'bold',
    color: '#000000'
  },
  recommendationTitle: {
    fontSize: isMobile ? 18 : 24,
    fontWeight: 'bold',
    color: '#000000'
  },
  seeAllText: {
    fontSize: isMobile ? 14 : 16,
    color: '#8B4513',
    fontWeight: '600'
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between'
  },
  categoryCard: {
    width: isMobile ? (width - 50) / 2 : (width - 90) / 4,
    height: isMobile ? 180 : 250, // Increased height for better image display
    marginBottom: 15,
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
    borderLeftWidth: 4,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3
  },
  categoryImage: {
    width: '100%',
    height: '100%',
    backgroundColor: '#f8f5f0' // Fallback color
  },
  categoryOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: isMobile ? 10 : 15
  },
  categoryName: {
    color: '#FFFFFF',
    fontSize: isMobile ? 13 : 16,
    fontWeight: 'bold',
    textAlign: 'center'
  },
  recommendationsContainer: {
    padding: isMobile ? 20 : 30,
    backgroundColor: '#FFFFFF',
    marginTop: 10
  },
  recommendationsScroll: {
    marginHorizontal: isMobile ? -5 : -10
  },
  recommendationCard: {
    width: isMobile ? width * 0.7 : width * 0.35, // Wider for better image display
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginHorizontal: isMobile ? 8 : 12,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#F0F0F0'
  },
  badge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#000000',
    paddingHorizontal: isMobile ? 6 : 8,
    paddingVertical: isMobile ? 2 : 4,
    borderRadius: 8,
    zIndex: 1
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: isMobile ? 9 : 11,
    fontWeight: 'bold'
  },
  recommendationImage: {
    width: '100%',
    height: isMobile ? 200 : 250, // Increased height for better quality
    backgroundColor: '#f8f5f0' // Fallback color
  },
  recommendationInfo: {
    padding: isMobile ? 12 : 16
  },
  recommendationName: {
    fontSize: isMobile ? 14 : 16,
    fontWeight: 'bold',
    color: '#000000',
    marginBottom: 4
  },
  recommendationDescription: {
    fontSize: isMobile ? 11 : 13,
    color: '#666666',
    marginBottom: 6
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8
  },
  starsContainer: {
    flexDirection: 'row',
    marginRight: 5
  },
  star: {
    fontSize: isMobile ? 10 : 12,
    marginRight: 1
  },
  ratingText: {
    fontSize: isMobile ? 10 : 12,
    color: '#666666'
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap'
  },
  currentPrice: {
    fontSize: isMobile ? 16 : 18,
    fontWeight: 'bold',
    color: '#000000',
    marginRight: 6
  },
  originalPrice: {
    fontSize: isMobile ? 12 : 14,
    color: '#999999',
    textDecorationLine: 'line-through',
    marginRight: 6
  },
  discount: {
    fontSize: isMobile ? 11 : 13,
    color: '#10B981',
    fontWeight: 'bold'
  },
  secondBannerContainer: {
    height: isMobile ? 200 : 300, // Increased height
    position: 'relative',
    margin: isMobile ? 20 : 30,
    marginTop: 10,
    borderRadius: 12,
    overflow: 'hidden'
  },
  secondBannerImage: {
    width: '100%',
    height: '100%',
    backgroundColor: '#f8f5f0' // Fallback color
  },
  secondBannerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: isMobile ? 15 : 25,
    justifyContent: 'center'
  },
  secondBannerTitle: {
    color: '#FFFFFF',
    fontSize: isMobile ? 20 : 28,
    fontWeight: 'bold',
    marginBottom: 4
  },
  secondBannerSubtitle: {
    color: '#CCCCCC',
    fontSize: isMobile ? 14 : 16,
    marginBottom: 12
  },
  secondBannerButton: {
    backgroundColor: '#000000',
    paddingVertical: isMobile ? 8 : 12,
    paddingHorizontal: isMobile ? 20 : 25,
    borderRadius: 18,
    alignSelf: 'flex-start'
  },
  secondBannerButtonText: {
    color: '#FFFFFF',
    fontSize: isMobile ? 13 : 15,
    fontWeight: 'bold'
  }
});

export default HomeScreen;